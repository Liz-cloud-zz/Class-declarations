import java.util.Scanner;

public class Ticket{
     
     private String id;
     public Time issueTime;
     
     /*
      *Create a new Ticket that has th egiven time.
     */
     
     public Ticket(Time currentTime){
            this.issueTime = currentTime;
            this.id=UIDGenerator.makeUID();
          
     }
     /*
      *Obtain this Tickect's ID
     */
     public String ID(){
            return this.id ;
     }
     /*
     *Obtain this ticket's age i.e. the issue time subtracted from the given time. 
     */ 
     
     public Duration age(Time currentTime){
             Duration D = new Duration(currentTime.subtract(this.issueTime));
             return D;
     }
     /*
     *Obtain a String representation of this Tickect object in the form:
     *"Ticket[id="ddddd", time="hh:mm:ss"]."
     */     
     public String toString(){
            return ("Ticket[id="+ this.id +", time=" + this.issueTime + "]");   
     }
     
     
 }           