
public class Clock {
       /*
       *A Clock object is used to simulate time and the passing of time.
       *A Clock can be examined and the time advanced.(It does not advance time on its own, hence "simulate.")
       */
       
       public Time currentTime;
       
       /*
        *Create a Clock set to the given time.
        */
        public Clock(Time time){
               this.currentTime= time;
        }
        
        /*
         *Advance the clock time by the given duration.
        */
        public void advance(Duration duration){
            Time t =  (this.currentTime).add(duration);
            this.currentTime=t;
        }        
       
       /*
        *Obtain the current time(as recorded by this clock).
        */
        
        public Time examine(){
               return this.currentTime;
        }       
}
       