import java.util.Scanner;
/**
 * The CarParkSim class contains the main car park simulation method.
 * It creates and manipulates the main objects, and handles user I/O.
 *
 * @author Stephan Jamieson and ...
 * @version 14/7/2019
 */
public class CarParkSim {
        
    public static void main(final String[] args) {
        final Scanner keyboard = new Scanner(System.in);
        // YOUR CODE HERE.
        
        // Declare variables to store a Clock and a Register object, create the relevant objects and assign them. 
        Time time= new Time("00:00:00");
        Clock c= new Clock(time);
        Register r= new Register();
        Ticket t=null;
        String id;
        
        System.out.println("Car Park Simulator");
        // YOUR CODE HERE.
        System.out.println("The current time is "+ time.toString()+".");
        // Print current time.
        System.out.println("Commands: advance {minutes}, arrive, depart, quit.");
        System.out.print(">");
        String input = keyboard.next().toLowerCase();
        long duration= 0;
        Duration d= new Duration(duration);
        
        while (!input.equals("quit")) {
            if (input.equals("advance")) {
                // YOUR CODE HERE.
                duration=keyboard.nextInt();
                d= new Duration("minutes", duration);
                c.advance(d);
                time =  c.examine();
               System.out.println("The current time is "+ time.toString()+".");// Advance the clock, print the current time.
            }
            else if (input.equals("arrive")) {
                // YOUR CODE HERE.
                t= new Ticket(time);
                r.add(t);
                System.out.println("Ticket issued: "+t.toString()+".");
                // Create a new ticket, add it to the register, print details of ticket issued.
            }
            else if (input.equals("depart")) {
                // YOUR CODE HERE.
                
                /*
                *Determine if ticket is valid, i.e. in the register.
                */ 
                  id=keyboard.next();
    
                  if ((r.contains(id)==true)){   
                     
                        Ticket tick =  r.retrieve(id);
                        System.out.println("Ticket details: "+tick.toString()+".");
                        System.out.println("Current time: "+ time.toString()+".");
                        Duration d2= new Duration (tick.age(time));
                        long hours=d2.intValue("hour");
                        long min=d2.intValue("minute");
                        if ((min >= 60)&&(hours >0)){
                           min= min-(60*hours);
                        }   
                        System.out.println("Duration of stay: "+hours+" hours"+" "+min+" minutes.");
                  }     
                      /*
                      * If yes, retreive it, calculate duration of stay and print it.
                      */
                     
                  else {
                           System.out.println("Invalid ticket ID.");
                  } 
                  /*
                  *If not, print error message.
                  */
           }
           else {
                  System.out.println("That command is not recognised.");
                  System.out.println("Commands: advance <minutes>, arrive, depart, quit.");
           }            
          System.out.print(">");
          input = keyboard.next().toLowerCase();
              
        }            
        System.out.println("Goodbye.");
    }

}
