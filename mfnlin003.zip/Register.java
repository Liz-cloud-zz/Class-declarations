
public class Register{
       /*
        *A register stores a collection of Tickets. A Ticket may be retrived given its ID.
        */
        
       public Ticket[] tickets;
       public int numTickets;
       
       /*
        *Create a new Register object
        */ 
        
        public Register(){
               
               this.numTickets=0;
               this.tickets =new Ticket[100];
        }    
               
       
        
        /*
         *Store the given ticket in the register.
         */
         
        public void add(Ticket ticket){
               this.tickets[this.numTickets]=ticket;
               this.numTickets= this.numTickets + 1;
               
        }
        
        /*
         *Determine whether a ticket with the given ID is in the  collection.
         */
         
         public boolean contains(String ticketID){
                
                try{
                for(Ticket t: this.tickets){
                   if ((t.ID()).equals(ticketID)){
                    return true;
                   }
                }}catch(NullPointerException e){
                       return false; 
                }
                return false; 
         }
         
         /*
          *Get the ticket with the given ID  from the collection.
          */
          
      public Ticket retrieve(String ticketID){
         
         Ticket ticket = null;
         try{
         for(Ticket tick: this.tickets){
            if ((tick.ID()).equals(ticketID))
               ticket =  tick;
 
         
         }}catch(NullPointerException e){
                 return ticket;
           }      
         
         return ticket;   
 
      }       
 
                                  
}                       